"""Pendaftaran, login, dan pengelolaan akun dinamis melalui backend."""

import hashlib
import hmac
import re

from .api import api_post
from .config import AUTH_SIGNING_KEY, PUBLIC_REGISTRATION_ROLES, VALID_ROLES


MIN_PASSWORD_LENGTH = 8
MAX_PASSWORD_LENGTH = 128


def normalize_username(value: str) -> str:
    username = str(value or "").strip().lower()
    if not re.fullmatch(r"[a-z0-9._-]{4,32}", username):
        raise ValueError(
            "Username harus 4–32 karakter dan hanya boleh berisi huruf kecil, angka, titik, garis bawah, atau tanda minus."
        )
    return username


def normalize_full_name(value: str) -> str:
    name = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(name) < 3:
        raise ValueError("Nama lengkap minimal 3 karakter.")
    if len(name) > 80:
        raise ValueError("Nama lengkap maksimal 80 karakter.")
    if any(ord(char) < 32 for char in name):
        raise ValueError("Nama mengandung karakter yang tidak valid.")
    return name


def normalize_position(value: str) -> str:
    position = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(position) < 2:
        raise ValueError("Jabatan minimal 2 karakter.")
    if len(position) > 80:
        raise ValueError("Jabatan maksimal 80 karakter.")
    if any(ord(char) < 32 for char in position):
        raise ValueError("Jabatan mengandung karakter yang tidak valid.")
    return position


def validate_password(password: str) -> str:
    value = str(password or "")
    if len(value) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"Password minimal {MIN_PASSWORD_LENGTH} karakter.")
    if len(value) > MAX_PASSWORD_LENGTH:
        raise ValueError(f"Password maksimal {MAX_PASSWORD_LENGTH} karakter.")
    return value


def password_verifier(password: str, username: str) -> str:
    """Buat verifier unik per username; password asli tidak dikirim atau disimpan."""
    if not AUTH_SIGNING_KEY:
        raise RuntimeError("AUTH_SIGNING_KEY diperlukan untuk fitur akun dinamis.")
    clean_password = str(password or "")
    return hmac.new(
        str(AUTH_SIGNING_KEY).encode("utf-8"),
        f"{normalize_username(username)}\0{clean_password}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def register_account(
    full_name: str, username: str, password: str, requested_role: str, position: str
):
    if requested_role not in PUBLIC_REGISTRATION_ROLES:
        raise ValueError(
            "Pendaftaran publik hanya dapat meminta role Staff atau Admin."
        )
    clean_username = normalize_username(username)
    return api_post(
        {
            "action": "account_register",
            "actor": "Public Registration",
            "role": "Staff",
            "full_name": normalize_full_name(full_name),
            "username": clean_username,
            "password_verifier": password_verifier(
                validate_password(password), clean_username
            ),
            "requested_role": requested_role,
            "position": normalize_position(position),
        },
        timeout=30,
    )


def authenticate_account(username: str, password: str):
    try:
        clean_username = normalize_username(username)
        validate_password(password)
    except ValueError:
        return {"authenticated": False, "status": "INVALID"}
    return api_post(
        {
            "action": "account_auth",
            "actor": "Login",
            "role": "Staff",
            "username": clean_username,
            "password_verifier": password_verifier(password, clean_username),
        },
        timeout=20,
    )


def list_accounts():
    from .auth import actor_payload

    return api_post({"action": "account_list", **actor_payload()}, timeout=30).get(
        "accounts", []
    )


def approve_account(username: str, role: str):
    from .auth import actor_payload

    if role not in VALID_ROLES:
        raise ValueError("Role tidak valid.")
    return api_post(
        {
            "action": "account_approve",
            "username": normalize_username(username),
            "new_role": role,
            **actor_payload(),
        },
        timeout=30,
    )


def reject_account(username: str):
    from .auth import actor_payload

    return api_post(
        {
            "action": "account_reject",
            "username": normalize_username(username),
            **actor_payload(),
        },
        timeout=30,
    )


def update_account(username: str, role: str, status: str):
    from .auth import actor_payload

    if role not in VALID_ROLES:
        raise ValueError("Role tidak valid.")
    if status not in {"ACTIVE", "SUSPENDED"}:
        raise ValueError("Status akun tidak valid.")
    return api_post(
        {
            "action": "account_update",
            "username": normalize_username(username),
            "new_role": role,
            "new_status": status,
            **actor_payload(),
        },
        timeout=30,
    )


def validate_account_session(username: str):
    """Pastikan akun dinamis masih aktif dan ambil role terbaru dari backend."""
    from .auth import actor_payload

    return api_post(
        {
            "action": "account_validate",
            "username": normalize_username(username),
            **actor_payload(),
        },
        timeout=15,
    )


def delete_account(username: str, confirmation: str):
    """Hapus record akun dan password verifier secara permanen.

    Audit operasional sengaja tidak dihapus agar jejak perubahan stok tetap utuh.
    Backend tetap menjadi pengaman terakhir untuk akun sendiri dan Developer terakhir.
    """
    from .auth import actor_payload

    clean_username = normalize_username(username)
    if str(confirmation or "").strip().casefold() != clean_username.casefold():
        raise ValueError("Konfirmasi username tidak sesuai.")
    return api_post(
        {
            "action": "account_delete",
            "username": clean_username,
            "confirm": f"DELETE:{clean_username}",
            **actor_payload(),
        },
        timeout=30,
    )

