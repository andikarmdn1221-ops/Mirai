/**
 * Mirai Backend v8.0
 *
 * Semua credential wajib disimpan di Apps Script > Project Settings >
 * Script Properties. Jangan menaruh token, key, atau ID produksi di file ini.
 *
 * Wajib:
 * - SPREADSHEET_ID
 * - API_SHARED_KEY
 * - AUTH_SIGNING_KEY
 *
 * Opsional:
 * - DRIVE_FOLDER_ID
 * - ACCOUNT_TELEGRAM_BOT_TOKEN
 * - ACCOUNT_TELEGRAM_CHAT_ID
 * - TELEGRAM_APPROVER_USER_ID
 * - TELEGRAM_WEBHOOK_SECRET
 * - LOCAL_ACCOUNT_ROLES_JSON, contoh:
 *   {"andika":"Developer","bos":"Boss"}
 * - REQUIRE_HMAC=true
 * - REQUIRE_SERVER_BACKUP_BEFORE_RESET=true
 */

const BACKEND_VERSION = "8.0-atomic";
const SCHEMA_CACHE_SECONDS = 300;
const SHEET_STOCK = "stok";
const SHEET_HISTORY = "riwayat";
const SHEET_AUDIT = "audit";
const SHEET_ACCOUNTS = "accounts";

const STOCK_HEADERS = [
  "Nama Barang",
  "Jumlah Stok",
  "Status",
  "Batas Minimum",
  "ID Barang",
];
const HISTORY_HEADERS = [
  "ID Transaksi",
  "Waktu",
  "Tanggal",
  "Tipe",
  "Barang",
  "Jumlah",
  "Pembeli / Keterangan",
  "Bukti URL",
  "Status",
  "Referensi",
  "ID Barang",
];
const AUDIT_HEADERS = [
  "Waktu",
  "User",
  "Role",
  "Aksi",
  "ID Transaksi",
  "Detail",
];
const ACCOUNT_HEADERS = [
  "Request ID",
  "Nama Lengkap",
  "Username",
  "Password Verifier",
  "Jabatan",
  "Role Diminta",
  "Role",
  "Status",
  "Dibuat",
  "Diperbarui",
  "Disetujui Oleh",
];

const VALID_ROLES = ["Staff", "Admin", "Boss", "Developer"];
const PUBLIC_ROLES = ["Staff", "Admin"];
const DEFAULT_STOCK = [
  ["Microcement base", 16, "Aktif", 5],
  ["Ready to use", 15, "Aktif", 5],
  ["Mixed resin A", 12, "Aktif", 5],
  ["Ceramic microcement", 4, "Aktif", 5],
  ["Microrock", 17, "Aktif", 5],
  ["Primer ordinary", 7, "Aktif", 5],
  ["Epoxy primer", 3, "Aktif", 5],
  ["Self leveling white finish", 4, "Aktif", 5],
  ["Top coat A", 15, "Aktif", 5],
  ["Top coat B", 1, "Aktif", 5],
  ["Top coat C", 5, "Aktif", 5],
  ["Pewarna no 1", 3, "Aktif", 5],
  ["Pewarna no 2", 10, "Aktif", 5],
  ["Pewarna no 3", 0, "Aktif", 5],
  ["Pewarna no 4", 9, "Aktif", 5],
  ["Metal glaze wax", 0, "Aktif", 5],
  ["Metallic glaze wax", 0, "Aktif", 5],
];

function doGet() {
  return jsonResponse_({
    ok: false,
    message: "GET dinonaktifkan. Gunakan signed POST dari aplikasi WMS.",
    backend_version: BACKEND_VERSION,
  });
}

function doPost(e) {
  const requestStartedAt = Date.now();
  try {
    if (e && e.parameter && e.parameter.telegram_secret) {
      return handleTelegramWebhook_(e);
    }

    const payload = parseJsonBody_(e);
    verifySignedRequest_(payload);
    const result = routeRequest_(payload);
    return jsonResponse_(
      Object.assign({ ok: true }, result || {}, {
        server_duration_ms: Date.now() - requestStartedAt,
      })
    );
  } catch (error) {
    console.error("[WMS backend] " + safeError_(error));
    return jsonResponse_({
      ok: false,
      message: safeError_(error),
      server_duration_ms: Date.now() - requestStartedAt,
    });
  }
}

function routeRequest_(payload) {
  const action = String(payload.action || "").trim();
  switch (action) {
    case "health":
      return handleHealth_(payload);
    case "read":
      return handleRead_(payload);
    case "transaction":
      return withScriptLock_(function () {
        return handleTransaction_(payload);
      });
    case "master_add":
      return withScriptLock_(function () {
        return handleMasterAdd_(payload);
      });
    case "master_update":
      return withScriptLock_(function () {
        return handleMasterUpdate_(payload);
      });
    case "master_delete":
      return withScriptLock_(function () {
        return handleMasterDelete_(payload);
      });
    case "transaction_correct":
      return withScriptLock_(function () {
        return handleTransactionCorrect_(payload);
      });
    case "transaction_void":
      return withScriptLock_(function () {
        return handleTransactionVoid_(payload);
      });
    case "stock_adjust":
      return withScriptLock_(function () {
        return handleStockAdjust_(payload);
      });
    case "reset":
      return withScriptLock_(function () {
        return handleReset_(payload);
      });
    case "audit_clear":
      return withScriptLock_(function () {
        return handleAuditClear_(payload);
      });
    case "server_backup":
      return handleServerBackup_(payload);
    case "backup_status":
      return handleBackupStatus_(payload);
    case "install_backup_trigger":
      return handleInstallBackupTrigger_(payload);
    case "remove_backup_trigger":
      return handleRemoveBackupTrigger_(payload);
    case "account_register":
      return withScriptLock_(function () {
        return handleAccountRegister_(payload);
      });
    case "account_auth":
      return handleAccountAuth_(payload);
    case "account_validate":
      return handleAccountValidate_(payload);
    case "account_list":
      return handleAccountList_(payload);
    case "account_approve":
      return withScriptLock_(function () {
        return handleAccountApprove_(payload);
      });
    case "account_reject":
      return withScriptLock_(function () {
        return handleAccountReject_(payload);
      });
    case "account_update":
      return withScriptLock_(function () {
        return handleAccountUpdate_(payload);
      });
    case "account_delete":
      return withScriptLock_(function () {
        return handleAccountDelete_(payload);
      });
    default:
      throw new Error("Action tidak dikenal.");
  }
}

function handleHealth_(payload) {
  // Endpoint health hanya mengembalikan metadata non-sensitif. Signature dan
  // identitas tetap divalidasi, tetapi tidak perlu membuka Google Sheets.
  resolveHealthIdentity_(payload);
  const properties = PropertiesService.getScriptProperties();
  return {
    backend_version: BACKEND_VERSION,
    data_revision: properties.getProperty("DATA_REVISION") || "0",
    server_time: nowText_(),
  };
}

function handleRead_(payload) {
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  // Pakai spreadsheet yang sama untuk validasi akun dan pembacaan data.
  // Sebelumnya proses ini membuka file serta memeriksa schema dua kali.
  const actor = resolveActor_(payload, spreadsheet, true);
  return {
    backend_version: BACKEND_VERSION,
    data_revision:
      PropertiesService.getScriptProperties().getProperty("DATA_REVISION") || "0",
    server_time: nowText_(),
    stok: getSheetValues_(spreadsheet.getSheetByName(SHEET_STOCK)),
    riwayat: getSheetValues_(spreadsheet.getSheetByName(SHEET_HISTORY)),
    audit:
      actor.role === "Developer" || actor.role === "Boss"
        ? getSheetValues_(spreadsheet.getSheetByName(SHEET_AUDIT))
        : [AUDIT_HEADERS],
  };
}

function handleTransaction_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, VALID_ROLES);
  const type = String(payload.tipe || "").toUpperCase();
  if (type !== "MASUK" && type !== "KELUAR") {
    throw new Error("Tipe transaksi tidak valid.");
  }

  const itemName = cleanText_(payload.barang, 80, true);
  const amount = positiveInt_(payload.jumlah, "Jumlah");
  const note = cleanText_(
    payload.keterangan,
    240,
    type === "KELUAR"
  );
  const txId = cleanText_(payload.tx_id, 80, true);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const stockSheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const historySheet = spreadsheet.getSheetByName(SHEET_HISTORY);
  const itemId = String(payload.item_id || "").trim();
  const found = findStockRowById_(stockSheet, itemId) || findStockRow_(stockSheet, itemName);
  if (!found) {
    throw new Error("Barang tidak ditemukan.");
  }
  if (found.status !== "Aktif") {
    throw new Error("Barang sedang nonaktif.");
  }

  // The client retries a signed request after a network timeout. Treat the
  // transaction ID as an idempotency key so a successful mutation is never
  // applied twice. A reused ID with different data is always rejected.
  const existing = findHistoryRow_(historySheet, txId);
  if (existing) {
    const sameItem = existing.itemId
      ? existing.itemId === found.itemId
      : sameText_(existing.item, found.name);
    if (
      existing.status === "AKTIF" &&
      (existing.type === "MASUK" || existing.type === "KELUAR") &&
      existing.type === type &&
      existing.amount === amount &&
      sameItem
    ) {
      return {
        tx_id: txId,
        stok_akhir: found.quantity,
        file_url: existing.proofUrl,
        alert: "",
        idempotent: true,
      };
    }
    throw new Error("ID transaksi sudah digunakan untuk data berbeda.");
  }

  if (
    payload.expected_stock_before !== undefined &&
    payload.expected_stock_before !== null &&
    intValue_(payload.expected_stock_before, "Stok sebelumnya") !== found.quantity
  ) {
    throw new Error(
      "Stok sudah berubah oleh pengguna lain. Segarkan data lalu ulangi transaksi."
    );
  }

  const finalStock =
    type === "MASUK" ? found.quantity + amount : found.quantity - amount;
  if (finalStock < 0) {
    throw new Error("Stok tidak mencukupi.");
  }

  // Commit stock, history and audit together with rollback protection. The
  // optional evidence is uploaded after the business mutation, so an upload
  // failure cannot leave stock changed without a transaction record.
  const historyRow = applyStockMutation_(
    spreadsheet,
    [{ row: found.row, before: found.quantity, after: finalStock }],
    [
    txId,
    cleanText_(payload.waktu, 40, true),
    cleanText_(payload.tanggal, 20, true),
    type,
    found.name,
    amount,
    note,
    "",
    "AKTIF",
    "",
    found.itemId,
    ],
    actor,
    "TRANSACTION_" + type,
    txId,
    found.name + " " + amount + " pcs; stok akhir " + finalStock
  );
  let proofUrl = "";
  let evidenceError = "";
  if (payload.image_base64) {
    try {
      proofUrl = saveEvidence_(payload);
      if (proofUrl) {
        historySheet.getRange(historyRow, 8).setValue(proofUrl);
      }
    } catch (error) {
      evidenceError = safeError_(error);
      console.error("[WMS evidence] " + evidenceError);
    }
  }
  bumpRevision_();

  return {
    tx_id: txId,
    stok_akhir: finalStock,
    file_url: proofUrl,
    alert: stockAlert_(found.name, finalStock, found.minimum),
    evidence_error: evidenceError,
  };
}

function handleMasterAdd_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  const name = cleanText_(payload.nama, 80, true);
  const initial = nonNegativeInt_(payload.stok_awal, "Stok awal");
  const minimum = positiveInt_(payload.min_stok, "Batas minimum");
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const stockSheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const historySheet = spreadsheet.getSheetByName(SHEET_HISTORY);
  const txId = cleanText_(payload.tx_id, 80, true);
  const existingTx = findHistoryRow_(historySheet, txId);
  if (existingTx) {
    if (
      existingTx.status === "AKTIF" &&
      existingTx.type === "BARANG BARU" &&
      sameText_(existingTx.item, name) &&
      existingTx.amount === initial
    ) {
      return { name: existingTx.item, stok_akhir: initial, idempotent: true };
    }
    throw new Error("ID transaksi sudah digunakan untuk data berbeda.");
  }
  const itemId = newItemId_();
  if (findStockRow_(stockSheet, name)) {
    throw new Error("Nama barang sudah digunakan.");
  }
  const auditSheet = spreadsheet.getSheetByName(SHEET_AUDIT);
  const stockRow = stockSheet.getLastRow() + 1;
  const historyRow = historySheet.getLastRow() + 1;
  const auditLastRow = auditSheet.getLastRow();
  try {
    stockSheet.appendRow([name, initial, "Aktif", minimum, itemId]);
    historySheet.appendRow([
      txId,
      cleanText_(payload.waktu, 40, true),
      "",
      "BARANG BARU",
      name,
      initial,
      "Master item baru",
      "",
      "AKTIF",
      "",
      itemId,
    ]);
    writeAudit_(
      spreadsheet,
      actor,
      "MASTER_ADD",
      txId,
      name + "; stok awal " + initial
    );
    SpreadsheetApp.flush();
  } catch (error) {
    if (auditSheet.getLastRow() > auditLastRow) {
      auditSheet.deleteRow(auditLastRow + 1);
    }
    if (historySheet.getLastRow() >= historyRow) {
      historySheet.deleteRow(historyRow);
    }
    if (stockSheet.getLastRow() >= stockRow) {
      stockSheet.deleteRow(stockRow);
    }
    SpreadsheetApp.flush();
    throw error;
  }
  bumpRevision_();
  return { name: name, stok_akhir: initial };
}

function handleMasterUpdate_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  const oldName = cleanText_(payload.old_nama, 80, true);
  const newName = cleanText_(payload.new_nama, 80, true);
  const status = normalizeItemStatus_(payload.status);
  const minimum = positiveInt_(payload.min_stok, "Batas minimum");
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const sheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const current = findStockRow_(sheet, oldName);
  if (!current) {
    throw new Error("Barang tidak ditemukan.");
  }
  const duplicate = findStockRow_(sheet, newName);
  if (duplicate && duplicate.row !== current.row) {
    throw new Error("Nama barang sudah digunakan item lain.");
  }
  const oldItemId = current.itemId;
  // Keep historical rows linked to the same item when its display name is
  // changed. This preserves void/correction/delete safeguards for old data.
  const historySheet = spreadsheet.getSheetByName(SHEET_HISTORY);
  const historyRows = dataRows_(historySheet, HISTORY_HEADERS);
  const historySnapshots = [];
  historyRows.forEach(function (row, index) {
    const rowItemId = String(row[10] || "").trim();
    const matches = oldItemId
      ? rowItemId === oldItemId || sameText_(row[4], oldName)
      : sameText_(row[4], oldName);
    if (matches) {
      historySnapshots.push({ row: index + 2, values: row.slice() });
    }
  });
  const auditSheet = spreadsheet.getSheetByName(SHEET_AUDIT);
  const auditLastRow = auditSheet.getLastRow();
  try {
    sheet.getRange(current.row, 1, 1, 4).setValues([
      [newName, current.quantity, status, minimum],
    ]);
    historySnapshots.forEach(function (snapshot) {
      historySheet.getRange(snapshot.row, 5).setValue(newName);
      historySheet.getRange(snapshot.row, 11).setValue(oldItemId);
    });
    writeAudit_(
      spreadsheet,
      actor,
      "MASTER_UPDATE",
      "",
      oldName + " -> " + newName + "; " + status
    );
    SpreadsheetApp.flush();
  } catch (error) {
    sheet.getRange(current.row, 1, 1, 4).setValues([
      [current.name, current.quantity, current.status, current.minimum],
    ]);
    historySnapshots.forEach(function (snapshot) {
      historySheet.getRange(snapshot.row, 1, 1, HISTORY_HEADERS.length).setValues([
        snapshot.values,
      ]);
    });
    if (auditSheet.getLastRow() > auditLastRow) {
      auditSheet.deleteRow(auditLastRow + 1);
    }
    SpreadsheetApp.flush();
    throw error;
  }
  bumpRevision_();
  return { name: newName };
}

function handleMasterDelete_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  const name = cleanText_(payload.nama, 80, true);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const stockSheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const itemId = String(payload.item_id || "").trim();
  const found = findStockRowById_(stockSheet, itemId) || findStockRow_(stockSheet, name);
  if (!found) {
    throw new Error("Barang tidak ditemukan.");
  }
  const historyRows = dataRows_(
    spreadsheet.getSheetByName(SHEET_HISTORY),
    HISTORY_HEADERS
  );
  const used = historyRows.some(function (row) {
    return sameText_(row[4], name) ||
      (found.itemId && String(row[10] || "").trim() === found.itemId);
  });
  if (used) {
    throw new Error(
      "Barang memiliki riwayat transaksi dan tidak boleh dihapus. Gunakan status Nonaktif."
    );
  }
  const deletedValues = stockSheet.getRange(found.row, 1, 1, STOCK_HEADERS.length).getValues()[0];
  const auditSheet = spreadsheet.getSheetByName(SHEET_AUDIT);
  const auditLastRow = auditSheet.getLastRow();
  try {
    stockSheet.deleteRow(found.row);
    writeAudit_(spreadsheet, actor, "MASTER_DELETE", "", name);
    SpreadsheetApp.flush();
  } catch (error) {
    stockSheet.insertRowBefore(found.row);
    stockSheet.getRange(found.row, 1, 1, STOCK_HEADERS.length).setValues([
      deletedValues,
    ]);
    if (auditSheet.getLastRow() > auditLastRow) {
      auditSheet.deleteRow(auditLastRow + 1);
    }
    SpreadsheetApp.flush();
    throw error;
  }
  bumpRevision_();
  return { deleted: true };
}

function handleStockAdjust_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  const name = cleanText_(payload.barang, 80, true);
  const newStock = nonNegativeInt_(payload.stok_baru, "Stok baru");
  const expected = nonNegativeInt_(
    payload.expected_stock_before,
    "Stok sebelumnya"
  );
  const reason = cleanText_(payload.alasan, 240, true);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const stockSheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const itemId = String(payload.item_id || "").trim();
  const found = findStockRowById_(stockSheet, itemId) || findStockRow_(stockSheet, name);
  if (!found) {
    throw new Error("Barang tidak ditemukan.");
  }
  const txId = cleanText_(payload.tx_id, 80, true);
  const historySheet = spreadsheet.getSheetByName(SHEET_HISTORY);
  const existing = findHistoryRow_(historySheet, txId);
  if (existing) {
    if (
      existing.status === "AKTIF" &&
      existing.type === "PENYESUAIAN" &&
      existing.itemId === found.itemId &&
      existing.amount === newStock - expected
    ) {
      return { tx_id: txId, selisih: existing.amount, stok_akhir: found.quantity, idempotent: true };
    }
    throw new Error("ID transaksi sudah digunakan untuk data berbeda.");
  }
  if (found.quantity !== expected) {
    throw new Error(
      "Stok sudah berubah oleh pengguna lain. Segarkan data lalu ulangi."
    );
  }
  const difference = newStock - found.quantity;
  applyStockMutation_(
    spreadsheet,
    [{ row: found.row, before: found.quantity, after: newStock }],
    [
    txId,
    cleanText_(payload.waktu, 40, true),
    cleanText_(payload.tanggal, 20, true),
    "PENYESUAIAN",
    found.name,
    difference,
    reason,
    "",
    "AKTIF",
    "",
    found.itemId,
    ],
    actor,
    "STOCK_ADJUST",
    txId,
    found.name + " " + found.quantity + " -> " + newStock + "; " + reason
  );
  bumpRevision_();
  return {
    tx_id: txId,
    selisih: difference,
    stok_akhir: newStock,
    alert: stockAlert_(found.name, newStock, found.minimum),
  };
}

function handleTransactionVoid_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  const txId = cleanText_(payload.tx_id, 80, true);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const historySheet = spreadsheet.getSheetByName(SHEET_HISTORY);
  const tx = findHistoryRow_(historySheet, txId);
  if (!tx) {
    throw new Error("Transaksi aktif tidak ditemukan.");
  }
  if (tx.status === "VOID") {
    const existingItem = findStockRowById_(
      spreadsheet.getSheetByName(SHEET_STOCK),
      tx.itemId
    ) || findStockRow_(spreadsheet.getSheetByName(SHEET_STOCK), tx.item);
    return {
      voided: true,
      stok_akhir: existingItem ? existingItem.quantity : "",
      idempotent: true,
    };
  }
  if (tx.status !== "AKTIF") {
    throw new Error("Transaksi aktif tidak ditemukan.");
  }
  if (tx.type !== "MASUK" && tx.type !== "KELUAR") {
    throw new Error("Jenis transaksi ini tidak dapat di-void.");
  }

  const stockSheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const item = findStockRowById_(stockSheet, tx.itemId) || findStockRow_(stockSheet, tx.item);
  if (!item) {
    throw new Error("Master barang transaksi tidak ditemukan.");
  }
  const finalStock =
    tx.type === "MASUK"
      ? item.quantity - tx.amount
      : item.quantity + tx.amount;
  if (finalStock < 0) {
    throw new Error("Void akan membuat stok negatif dan ditolak.");
  }

  const historyBefore = historySheet.getRange(tx.row, 9, 1, 2).getValues()[0];
  const auditSheet = spreadsheet.getSheetByName(SHEET_AUDIT);
  const auditLastRow = auditSheet.getLastRow();
  try {
    historySheet.getRange(tx.row, 9, 1, 2).setValues([["VOID", "VOID oleh " + actor.username]]);
    stockSheet.getRange(item.row, 2).setValue(finalStock);
    writeAudit_(
      spreadsheet,
      actor,
      "TRANSACTION_VOID",
      txId,
      tx.type + " " + tx.item + " " + tx.amount + " pcs"
    );
  } catch (error) {
    historySheet.getRange(tx.row, 9, 1, 2).setValues([historyBefore]);
    stockSheet.getRange(item.row, 2).setValue(item.quantity);
    if (auditSheet.getLastRow() > auditLastRow) {
      auditSheet.deleteRow(auditLastRow + 1);
    }
    SpreadsheetApp.flush();
    throw error;
  }
  bumpRevision_();
  return { voided: true, stok_akhir: finalStock };
}

function handleTransactionCorrect_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  const oldTxId = cleanText_(payload.tx_id, 80, true);
  const newTxId = cleanText_(payload.new_tx_id, 80, true);
  const newType = String(payload.new_tipe || "").toUpperCase();
  if (newType !== "MASUK" && newType !== "KELUAR") {
    throw new Error("Tipe koreksi tidak valid.");
  }
  const newItemName = cleanText_(payload.new_barang, 80, true);
  const newItemId = String(payload.new_item_id || "").trim();
  const newAmount = positiveInt_(payload.new_jumlah, "Jumlah koreksi");
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const historySheet = spreadsheet.getSheetByName(SHEET_HISTORY);
  const stockSheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const newItem = findStockRowById_(stockSheet, newItemId) || findStockRow_(stockSheet, newItemName);
  const oldTx = findHistoryRow_(historySheet, oldTxId);
  const existingReplacement = findHistoryRow_(historySheet, newTxId);
  if (existingReplacement) {
    const sameItem = existingReplacement.itemId && newItem
      ? existingReplacement.itemId === newItem.itemId
      : !newItem || sameText_(existingReplacement.item, newItemName);
    if (
      existingReplacement.status === "AKTIF" &&
      existingReplacement.reference === oldTxId &&
      existingReplacement.type === newType &&
      existingReplacement.amount === newAmount &&
      sameItem
    ) {
      return { new_tx_id: newTxId, idempotent: true };
    }
    throw new Error("ID transaksi pengganti sudah digunakan.");
  }
  if (!oldTx || oldTx.status !== "AKTIF") {
    throw new Error("Transaksi aktif tidak ditemukan.");
  }
  if (oldTx.type !== "MASUK" && oldTx.type !== "KELUAR") {
    throw new Error("Jenis transaksi ini tidak dapat dikoreksi.");
  }
  const oldItem = findStockRowById_(stockSheet, oldTx.itemId) || findStockRow_(stockSheet, oldTx.item);
  if (!oldItem || !newItem) {
    throw new Error("Master barang koreksi tidak ditemukan.");
  }

  const projected = {};
  const stockRows = dataRows_(stockSheet, STOCK_HEADERS);
  stockRows.forEach(function (row) {
    projected[String(row[0]).toLowerCase()] = intValue_(row[1], "Stok");
  });

  const oldKey = oldItem.name.toLowerCase();
  const newKey = newItem.name.toLowerCase();
  projected[oldKey] += oldTx.type === "MASUK" ? -oldTx.amount : oldTx.amount;
  if (projected[oldKey] < 0) {
    throw new Error("Koreksi akan membuat stok lama negatif.");
  }
  projected[newKey] += newType === "MASUK" ? newAmount : -newAmount;
  if (projected[newKey] < 0) {
    throw new Error("Stok tidak mencukupi untuk hasil koreksi.");
  }

  const changes = [{ row: oldItem.row, before: oldItem.quantity, after: projected[oldKey] }];
  if (newItem.row !== oldItem.row) {
    changes.push({ row: newItem.row, before: newItem.quantity, after: projected[newKey] });
  }
  const oldHistoryStatus = historySheet.getRange(oldTx.row, 9, 1, 2).getValues()[0];
  const auditSheet = spreadsheet.getSheetByName(SHEET_AUDIT);
  const auditLastRow = auditSheet.getLastRow();
  const historyLastRow = historySheet.getLastRow();
  try {
    changes.forEach(function (change) {
      stockSheet.getRange(change.row, 2).setValue(change.after);
    });
    historySheet.getRange(oldTx.row, 9, 1, 2).setValues([["DIKOREKSI", newTxId]]);
    historySheet.appendRow([
    newTxId,
    cleanText_(payload.new_waktu, 40, true),
    cleanText_(payload.new_tanggal, 20, true),
    newType,
    newItem.name,
    newAmount,
    cleanText_(payload.new_keterangan, 240, false),
    oldTx.proofUrl,
    "AKTIF",
    oldTxId,
    newItem.itemId,
    ]);
    writeAudit_(
      spreadsheet,
      actor,
      "TRANSACTION_CORRECT",
      oldTxId,
      "Transaksi pengganti " + newTxId
    );
  } catch (error) {
    changes.forEach(function (change) {
      stockSheet.getRange(change.row, 2).setValue(change.before);
    });
    historySheet.getRange(oldTx.row, 9, 1, 2).setValues([oldHistoryStatus]);
    if (historySheet.getLastRow() > historyLastRow) {
      historySheet.deleteRow(historySheet.getLastRow());
    }
    if (auditSheet.getLastRow() > auditLastRow) {
      auditSheet.deleteRow(auditLastRow + 1);
    }
    SpreadsheetApp.flush();
    throw error;
  }
  bumpRevision_();
  return { new_tx_id: newTxId };
}

function handleAuditClear_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  if (String(payload.confirm || "") !== "HAPUS-AUDIT") {
    throw new Error("Konfirmasi penghapusan audit tidak valid.");
  }

  const backup = createServerBackup_();
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const auditSheet = spreadsheet.getSheetByName(SHEET_AUDIT);
  const deletedRows = Math.max(auditSheet.getLastRow() - 1, 0);

  resetSheet_(auditSheet, AUDIT_HEADERS);
  writeAudit_(
    spreadsheet,
    actor,
    "AUDIT_LOG_CLEARED",
    "",
    deletedRows + " catatan audit lama dihapus setelah backup " + backup.backup_name + "."
  );
  bumpRevision_();
  return {
    audit_cleared: true,
    deleted_rows: deletedRows,
    backup_name: backup.backup_name,
    backup_url: backup.backup_url,
  };
}

function handleReset_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  if (String(payload.confirm || "") !== "RESET-DATABASE") {
    throw new Error("Konfirmasi reset tidak valid.");
  }

  const requireBackup = getProperty_("REQUIRE_SERVER_BACKUP_BEFORE_RESET", "true")
    .toLowerCase() !== "false";
  if (requireBackup) {
    createServerBackup_();
  }

  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  resetSheet_(spreadsheet.getSheetByName(SHEET_STOCK), STOCK_HEADERS);
  const defaultStockWithIds = DEFAULT_STOCK.map(function (row) {
    return row.concat([newItemId_()]);
  });
  spreadsheet
    .getSheetByName(SHEET_STOCK)
    .getRange(2, 1, defaultStockWithIds.length, STOCK_HEADERS.length)
    .setValues(defaultStockWithIds);
  resetSheet_(spreadsheet.getSheetByName(SHEET_HISTORY), HISTORY_HEADERS);
  resetSheet_(spreadsheet.getSheetByName(SHEET_AUDIT), AUDIT_HEADERS);
  writeAudit_(
    spreadsheet,
    actor,
    "DATABASE_RESET",
    "",
    "Data operasional dikembalikan ke master awal."
  );
  bumpRevision_();
  return { reset: true };
}

function handleServerBackup_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  return createServerBackup_();
}

function handleBackupStatus_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer", "Boss", "Admin"]);
  const properties = PropertiesService.getScriptProperties();
  return {
    last_backup_time: properties.getProperty("LAST_BACKUP_TIME") || "",
    last_backup_url: properties.getProperty("LAST_BACKUP_URL") || "",
    last_backup_name: properties.getProperty("LAST_BACKUP_NAME") || "",
    trigger_installed: backupTriggerInstalled_(),
  };
}

function handleInstallBackupTrigger_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  if (!backupTriggerInstalled_()) {
    ScriptApp.newTrigger("scheduledDailyBackup")
      .timeBased()
      .everyDays(1)
      .atHour(1)
      .create();
  }
  return { trigger_installed: true };
}

function handleRemoveBackupTrigger_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (trigger.getHandlerFunction() === "scheduledDailyBackup") {
      ScriptApp.deleteTrigger(trigger);
    }
  });
  return { trigger_installed: false };
}

function scheduledDailyBackup() {
  createServerBackup_();
}

function handleAccountRegister_(payload) {
  const username = normalizeUsername_(payload.username);
  const fullName = cleanText_(payload.full_name, 80, true);
  const position = cleanText_(payload.position, 80, true);
  const requestedRole = normalizeRole_(payload.requested_role);
  if (PUBLIC_ROLES.indexOf(requestedRole) < 0) {
    throw new Error("Pendaftaran publik hanya dapat meminta Staff atau Admin.");
  }
  const verifier = String(payload.password_verifier || "").trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(verifier)) {
    throw new Error("Password verifier tidak valid.");
  }

  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const sheet = spreadsheet.getSheetByName(SHEET_ACCOUNTS);
  if (findAccount_(sheet, username)) {
    throw new Error("Username sudah digunakan.");
  }

  const requestId = "ACC-" + Utilities.getUuid().replace(/-/g, "").slice(0, 16).toUpperCase();
  const now = nowText_();
  sheet.appendRow([
    requestId,
    fullName,
    username,
    verifier,
    position,
    requestedRole,
    "",
    "PENDING",
    now,
    now,
    "",
  ]);
  writeAudit_(
    spreadsheet,
    { username: "Public Registration", role: "Staff" },
    "ACCOUNT_REGISTER",
    requestId,
    username + " meminta role " + requestedRole
  );
  bumpRevision_();
  return { request_id: requestId, status: "PENDING" };
}

function handleAccountAuth_(payload) {
  const username = normalizeUsername_(payload.username);
  const verifier = String(payload.password_verifier || "").trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(verifier)) {
    return { authenticated: false, status: "INVALID" };
  }
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const account = findAccount_(
    spreadsheet.getSheetByName(SHEET_ACCOUNTS),
    username
  );
  if (!account || !constantTimeEqual_(account.passwordVerifier, verifier)) {
    return { authenticated: false, status: "INVALID" };
  }
  if (account.status !== "ACTIVE") {
    return { authenticated: false, status: account.status };
  }
  return {
    authenticated: true,
    status: "ACTIVE",
    username: account.username,
    full_name: account.fullName,
    role: account.role,
  };
}

function handleAccountValidate_(payload) {
  const username = normalizeUsername_(payload.username);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const account = findAccount_(
    spreadsheet.getSheetByName(SHEET_ACCOUNTS),
    username
  );
  if (!account) {
    return { active: false, status: "DELETED" };
  }
  return {
    active: account.status === "ACTIVE",
    status: account.status,
    username: account.username,
    full_name: account.fullName,
    role: account.role || "Staff",
  };
}

function handleAccountList_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const rows = dataRows_(
    spreadsheet.getSheetByName(SHEET_ACCOUNTS),
    ACCOUNT_HEADERS
  );
  return {
    accounts: rows.map(function (row) {
      return {
        request_id: row[0],
        full_name: row[1],
        username: row[2],
        position: row[4],
        requested_role: row[5],
        role: row[6],
        status: row[7],
        created_at: row[8],
        updated_at: row[9],
        approved_by: row[10],
      };
    }),
  };
}

function handleAccountApprove_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  const username = normalizeUsername_(payload.username);
  const role = normalizeRole_(payload.new_role);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const sheet = spreadsheet.getSheetByName(SHEET_ACCOUNTS);
  const account = findAccount_(sheet, username);
  if (!account) {
    throw new Error("Akun tidak ditemukan.");
  }
  sheet.getRange(account.row, 7, 1, 5).setValues([
    [role, "ACTIVE", account.createdAt, nowText_(), actor.username],
  ]);
  writeAudit_(
    spreadsheet,
    actor,
    "ACCOUNT_APPROVE",
    account.requestId,
    username + " sebagai " + role
  );
  bumpRevision_();
  return { username: username, role: role, status: "ACTIVE" };
}

function handleAccountReject_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  const username = normalizeUsername_(payload.username);
  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const sheet = spreadsheet.getSheetByName(SHEET_ACCOUNTS);
  const account = findAccount_(sheet, username);
  if (!account) {
    throw new Error("Akun tidak ditemukan.");
  }
  sheet.getRange(account.row, 7, 1, 5).setValues([
    ["", "REJECTED", account.createdAt, nowText_(), actor.username],
  ]);
  writeAudit_(
    spreadsheet,
    actor,
    "ACCOUNT_REJECT",
    account.requestId,
    username
  );
  bumpRevision_();
  return { username: username, status: "REJECTED" };
}

function handleAccountUpdate_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  const username = normalizeUsername_(payload.username);
  const role = normalizeRole_(payload.new_role);
  const status = String(payload.new_status || "").toUpperCase();
  if (status !== "ACTIVE" && status !== "SUSPENDED") {
    throw new Error("Status akun tidak valid.");
  }
  if (sameText_(actor.username, username)) {
    throw new Error("Akun yang sedang digunakan tidak dapat diubah.");
  }

  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const sheet = spreadsheet.getSheetByName(SHEET_ACCOUNTS);
  const account = findAccount_(sheet, username);
  if (!account) {
    throw new Error("Akun tidak ditemukan.");
  }
  if (
    account.role === "Developer" &&
    (role !== "Developer" || status !== "ACTIVE") &&
    countActiveDevelopers_(sheet) <= 1
  ) {
    throw new Error("Developer aktif terakhir tidak dapat diturunkan atau dinonaktifkan.");
  }

  sheet.getRange(account.row, 7).setValue(role);
  sheet.getRange(account.row, 8).setValue(status);
  sheet.getRange(account.row, 10).setValue(nowText_());
  sheet.getRange(account.row, 11).setValue(actor.username);
  writeAudit_(
    spreadsheet,
    actor,
    "ACCOUNT_UPDATE",
    account.requestId,
    username + " -> " + role + "/" + status
  );
  bumpRevision_();
  return { username: username, role: role, status: status };
}

function handleAccountDelete_(payload) {
  const actor = resolveActor_(payload);
  requireRoles_(actor, ["Developer"]);
  const username = normalizeUsername_(payload.username);
  if (String(payload.confirm || "") !== "DELETE:" + username) {
    throw new Error("Konfirmasi penghapusan akun tidak valid.");
  }
  if (sameText_(actor.username, username)) {
    throw new Error("Akun yang sedang digunakan tidak dapat dihapus.");
  }

  const spreadsheet = getSpreadsheet_();
  ensureSchema_(spreadsheet);
  const sheet = spreadsheet.getSheetByName(SHEET_ACCOUNTS);
  const account = findAccount_(sheet, username);
  if (!account) {
    throw new Error("Akun tidak ditemukan.");
  }
  if (
    account.role === "Developer" &&
    account.status === "ACTIVE" &&
    countActiveDevelopers_(sheet) <= 1
  ) {
    throw new Error("Developer aktif terakhir tidak dapat dihapus.");
  }

  const requestId = account.requestId;
  sheet.deleteRow(account.row);
  writeAudit_(
    spreadsheet,
    actor,
    "ACCOUNT_DELETE_PERMANENT",
    requestId,
    "Record akun dan password verifier dihapus: " + username
  );
  bumpRevision_();
  return { username: username, deleted: true, status: "DELETED" };
}

function resolveHealthIdentity_(payload) {
  const username = String(payload.actor || "").trim();
  if (!username) {
    throw new Error("Identitas pengguna tidak tersedia.");
  }
  return {
    username: username,
    role: normalizeRole_(payload.role),
    source: String(payload.auth_source || "local").toLowerCase(),
  };
}

function resolveActor_(payload, existingSpreadsheet, schemaReady) {
  const username = String(payload.actor || "").trim();
  if (!username) {
    throw new Error("Identitas pengguna tidak tersedia.");
  }
  const source = String(payload.auth_source || "local").toLowerCase();
  let role = normalizeRole_(payload.role);

  const spreadsheet = existingSpreadsheet || getSpreadsheet_();
  if (!schemaReady) {
    ensureSchema_(spreadsheet);
  }
  const account = findAccount_(
    spreadsheet.getSheetByName(SHEET_ACCOUNTS),
    username
  );

  if (source === "dynamic" || account) {
    if (!account || account.status !== "ACTIVE") {
      throw new Error("Akun telah dinonaktifkan atau dihapus.");
    }
    role = normalizeRole_(account.role);
  } else {
    const trusted = trustedLocalRoles_();
    const keys = Object.keys(trusted);
    if (keys.length) {
      const trustedRole = trusted[String(username).trim().toLowerCase()];
      if (!trustedRole) {
        throw new Error("Akun lokal tidak terdaftar pada backend.");
      }
      role = normalizeRole_(trustedRole);
    }
  }

  return { username: username, role: role, source: source };
}

function trustedLocalRoles_() {
  const raw = getProperty_("LOCAL_ACCOUNT_ROLES_JSON", "");
  if (!raw) {
    return {};
  }
  try {
    const parsed = JSON.parse(raw);
    const result = {};
    Object.keys(parsed || {}).forEach(function (key) {
      result[String(key).trim().toLowerCase()] = normalizeRole_(parsed[key]);
    });
    return result;
  } catch (error) {
    throw new Error("LOCAL_ACCOUNT_ROLES_JSON tidak valid.");
  }
}

function requireRoles_(actor, roles) {
  if (roles.indexOf(actor.role) < 0) {
    throw new Error("Role tidak memiliki izin untuk operasi ini.");
  }
}

function parseJsonBody_(e) {
  if (!e || !e.postData || !e.postData.contents) {
    throw new Error("Body JSON tidak tersedia.");
  }
  try {
    const payload = JSON.parse(e.postData.contents);
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      throw new Error("Body JSON harus berupa object.");
    }
    return payload;
  } catch (error) {
    throw new Error("Body JSON tidak valid.");
  }
}

function verifySignedRequest_(payload) {
  const expectedApiKey = getRequiredProperty_("API_SHARED_KEY");
  if (!constantTimeEqual_(String(payload.api_key || ""), expectedApiKey)) {
    throw new Error("API key tidak valid.");
  }

  const requireHmac =
    getProperty_("REQUIRE_HMAC", "true").toLowerCase() !== "false";
  if (!requireHmac) {
    return;
  }

  const signingKey = getRequiredProperty_("AUTH_SIGNING_KEY");
  const timestamp = Number(payload.auth_ts);
  if (!Number.isFinite(timestamp)) {
    throw new Error("Timestamp autentikasi tidak valid.");
  }
  const nowSeconds = Math.floor(Date.now() / 1000);
  if (Math.abs(nowSeconds - timestamp) > 300) {
    throw new Error("Request kedaluwarsa.");
  }

  const nonce = String(payload.auth_nonce || "");
  if (!/^[a-f0-9]{32}$/i.test(nonce)) {
    throw new Error("Nonce tidak valid.");
  }
  const cache = CacheService.getScriptCache();
  const nonceKey = "nonce_" + nonce;

  const unsigned = {};
  Object.keys(payload).forEach(function (key) {
    if (
      key !== "api_key" &&
      key !== "auth_ts" &&
      key !== "auth_nonce" &&
      key !== "auth_body_sha256" &&
      key !== "auth_sig"
    ) {
      unsigned[key] = payload[key];
    }
  });
  const canonical = stableStringify_(unsigned);
  const bodyHash = sha256Hex_(canonical);
  if (
    !constantTimeEqual_(
      String(payload.auth_body_sha256 || "").toLowerCase(),
      bodyHash
    )
  ) {
    throw new Error("Hash body tidak valid.");
  }
  const expectedSignature = hmacSha256Hex_(
    bodyHash + "|" + String(payload.auth_ts) + "|" + nonce,
    signingKey
  );
  if (
    !constantTimeEqual_(
      String(payload.auth_sig || "").toLowerCase(),
      expectedSignature
    )
  ) {
    throw new Error("Signature request tidak valid.");
  }
  const nonceLock = LockService.getScriptLock();
  nonceLock.waitLock(5000);
  try {
    if (cache.get(nonceKey)) {
      throw new Error("Request duplikat ditolak.");
    }
    cache.put(nonceKey, "1", 600);
  } finally {
    nonceLock.releaseLock();
  }
}

function stableStringify_(value) {
  if (value === null || typeof value !== "object") {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return (
      "[" +
      value
        .map(function (item) {
          return stableStringify_(item);
        })
        .join(",") +
      "]"
    );
  }
  const keys = Object.keys(value).sort();
  return (
    "{" +
    keys
      .map(function (key) {
        return JSON.stringify(key) + ":" + stableStringify_(value[key]);
      })
      .join(",") +
    "}"
  );
}

function sha256Hex_(text) {
  return bytesToHex_(
    Utilities.computeDigest(
      Utilities.DigestAlgorithm.SHA_256,
      String(text),
      Utilities.Charset.UTF_8
    )
  );
}

function hmacSha256Hex_(text, key) {
  return bytesToHex_(
    Utilities.computeHmacSha256Signature(
      String(text),
      String(key),
      Utilities.Charset.UTF_8
    )
  );
}

function bytesToHex_(bytes) {
  return bytes
    .map(function (value) {
      const normalized = value < 0 ? value + 256 : value;
      return ("0" + normalized.toString(16)).slice(-2);
    })
    .join("");
}

function constantTimeEqual_(left, right) {
  const a = String(left || "");
  const b = String(right || "");
  let mismatch = a.length ^ b.length;
  const length = Math.max(a.length, b.length);
  for (let i = 0; i < length; i += 1) {
    mismatch |= (a.charCodeAt(i % Math.max(1, a.length)) || 0) ^
      (b.charCodeAt(i % Math.max(1, b.length)) || 0);
  }
  return mismatch === 0;
}

function getSpreadsheet_() {
  return SpreadsheetApp.openById(getRequiredProperty_("SPREADSHEET_ID"));
}

function ensureSchema_(spreadsheet) {
  const cache = CacheService.getScriptCache();
  const cacheKey = "schema_ready_" + BACKEND_VERSION;
  if (cache.get(cacheKey) === "1") {
    return;
  }

  const stockSheet = ensureSheet_(
    spreadsheet,
    SHEET_STOCK,
    STOCK_HEADERS,
    ["Nama Barang", "Jumlah Stok", "Status", "Batas Minimum"]
  );
  const historySheet = ensureSheet_(
    spreadsheet,
    SHEET_HISTORY,
    HISTORY_HEADERS,
    [
      "ID Transaksi",
      "Waktu",
      "Tanggal",
      "Tipe",
      "Barang",
      "Jumlah",
      "Pembeli / Keterangan",
      "Bukti URL",
      "Status",
      "Referensi",
    ]
  );
  ensureSheet_(spreadsheet, SHEET_AUDIT, AUDIT_HEADERS);
  ensureSheet_(spreadsheet, SHEET_ACCOUNTS, ACCOUNT_HEADERS);
  ensureItemIds_(stockSheet);
  migrateHistoryItemIds_(historySheet, stockSheet);
  cache.put(cacheKey, "1", SCHEMA_CACHE_SECONDS);
}

function ensureSheet_(spreadsheet, name, headers, legacyHeaders) {
  let sheet = spreadsheet.getSheetByName(name);
  if (!sheet) {
    sheet = spreadsheet.insertSheet(name);
  }
  let lastRow = sheet.getLastRow();
  const current = lastRow
    ? sheet.getRange(1, 1, 1, Math.max(headers.length, sheet.getLastColumn())).getValues()[0]
    : [];
  const correct = headers.every(function (header, index) {
    return String(current[index] || "").trim() === header;
  });
  const legacy =
    Array.isArray(legacyHeaders) &&
    legacyHeaders.every(function (header, index) {
      return String(current[index] || "").trim() === header;
    });
  if (!correct) {
    if (lastRow === 0) {
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      lastRow = 1;
    } else if (legacy) {
      // Backward-compatible schema migration: append the new column without
      // touching existing operational values.
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    } else {
      throw new Error(
        "Header sheet " + name + " tidak cocok. Jalankan migrasi sebelum menggunakan backend."
      );
    }
  }
  // Hindari operasi tulis pada setiap request hanya untuk pengaturan visual.
  if (lastRow === 1 && sheet.getFrozenRows() !== 1) {
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function getSheetValues_(sheet) {
  if (!sheet) {
    return [];
  }
  const lastRow = sheet.getLastRow();
  if (lastRow < 1) {
    return [];
  }
  const lastColumn = sheet.getLastColumn();
  return sheet
    .getRange(1, 1, lastRow, lastColumn)
    .getValues();
}

function dataRows_(sheet, headers) {
  if (!sheet || sheet.getLastRow() <= 1) {
    return [];
  }
  return sheet
    .getRange(2, 1, sheet.getLastRow() - 1, headers.length)
    .getValues();
}

function resetSheet_(sheet, headers) {
  sheet.clearContents();
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.setFrozenRows(1);
}

function newItemId_() {
  return "ITM-" + Utilities.getUuid().replace(/-/g, "").slice(0, 20).toUpperCase();
}

function ensureItemIds_(sheet) {
  const rows = dataRows_(sheet, STOCK_HEADERS);
  const seen = {};
  rows.forEach(function (row, index) {
    const existingId = String(row[4] || "").trim();
    if (existingId) {
      const key = existingId.toUpperCase();
      if (seen[key]) {
        throw new Error("ID Barang duplikat pada master: " + existingId);
      }
      seen[key] = true;
    } else if (String(row[0] || "").trim()) {
      const generatedId = newItemId_();
      sheet.getRange(index + 2, 5).setValue(generatedId);
      seen[generatedId.toUpperCase()] = true;
    }
  });
}

function migrateHistoryItemIds_(historySheet, stockSheet) {
  const rows = dataRows_(historySheet, HISTORY_HEADERS);
  rows.forEach(function (row, index) {
    if (String(row[10] || "").trim() || !String(row[4] || "").trim()) {
      return;
    }
    const item = findStockRow_(stockSheet, row[4]);
    if (item && item.itemId) {
      historySheet.getRange(index + 2, 11).setValue(item.itemId);
    }
  });
}

function findStockRow_(sheet, name) {
  const wanted = String(name || "").trim().toLowerCase();
  const rows = dataRows_(sheet, STOCK_HEADERS);
  for (let index = 0; index < rows.length; index += 1) {
    if (String(rows[index][0] || "").trim().toLowerCase() === wanted) {
      return {
        row: index + 2,
        name: String(rows[index][0]),
        quantity: nonNegativeInt_(rows[index][1], "Stok"),
        status: normalizeItemStatus_(rows[index][2]),
        minimum: positiveInt_(rows[index][3] || 5, "Batas minimum"),
        itemId: String(rows[index][4] || "").trim(),
      };
    }
  }
  return null;
}

function findStockRowById_(sheet, itemId) {
  const wanted = String(itemId || "").trim();
  if (!wanted) {
    return null;
  }
  const rows = dataRows_(sheet, STOCK_HEADERS);
  for (let index = 0; index < rows.length; index += 1) {
    if (String(rows[index][4] || "").trim() === wanted) {
      return {
        row: index + 2,
        name: String(rows[index][0]),
        quantity: nonNegativeInt_(rows[index][1], "Stok"),
        status: normalizeItemStatus_(rows[index][2]),
        minimum: positiveInt_(rows[index][3] || 5, "Batas minimum"),
        itemId: wanted,
      };
    }
  }
  return null;
}

function findHistoryRow_(sheet, txId) {
  const wanted = String(txId || "").trim();
  const rows = dataRows_(sheet, HISTORY_HEADERS);
  for (let index = 0; index < rows.length; index += 1) {
    if (String(rows[index][0] || "").trim() === wanted) {
      return {
        row: index + 2,
        txId: String(rows[index][0]),
        time: rows[index][1],
        date: rows[index][2],
        type: String(rows[index][3] || "").toUpperCase(),
        item: String(rows[index][4] || ""),
        amount: intValue_(rows[index][5], "Jumlah transaksi"),
        note: String(rows[index][6] || ""),
        proofUrl: String(rows[index][7] || ""),
        status: String(rows[index][8] || "").toUpperCase(),
        reference: String(rows[index][9] || ""),
        itemId: String(rows[index][10] || "").trim(),
      };
    }
  }
  return null;
}

function applyStockMutation_(spreadsheet, stockChanges, historyValues, actor, action, txId, detail) {
  const stockSheet = spreadsheet.getSheetByName(SHEET_STOCK);
  const historySheet = spreadsheet.getSheetByName(SHEET_HISTORY);
  const auditSheet = spreadsheet.getSheetByName(SHEET_AUDIT);
  const historyLastRow = historySheet.getLastRow();
  const auditLastRow = auditSheet.getLastRow();
  let historyWritten = false;
  let auditWritten = false;
  try {
    stockChanges.forEach(function (change) {
      stockSheet.getRange(change.row, 2).setValue(change.after);
    });
    historySheet.appendRow(historyValues);
    historyWritten = true;
    writeAudit_(spreadsheet, actor, action, txId, detail);
    auditWritten = true;
    SpreadsheetApp.flush();
    return historySheet.getLastRow();
  } catch (error) {
    // Apps Script SpreadsheetApp has no database transaction. The script lock
    // plus this compensating rollback prevents a failed write from leaving a
    // changed stock without its history/audit record.
    stockChanges.forEach(function (change) {
      stockSheet.getRange(change.row, 2).setValue(change.before);
    });
    if (auditWritten || auditSheet.getLastRow() > auditLastRow) {
      auditSheet.deleteRow(auditLastRow + 1);
    }
    if (historyWritten || historySheet.getLastRow() > historyLastRow) {
      historySheet.deleteRow(historyLastRow + 1);
    }
    SpreadsheetApp.flush();
    throw error;
  }
}

function findAccount_(sheet, usernameOrRequestId) {
  const wanted = String(usernameOrRequestId || "").trim().toLowerCase();
  const rows = dataRows_(sheet, ACCOUNT_HEADERS);
  for (let index = 0; index < rows.length; index += 1) {
    const requestId = String(rows[index][0] || "").trim().toLowerCase();
    const username = String(rows[index][2] || "").trim().toLowerCase();
    if (username === wanted || requestId === wanted) {
      return {
        row: index + 2,
        requestId: String(rows[index][0] || ""),
        fullName: String(rows[index][1] || ""),
        username: String(rows[index][2] || ""),
        passwordVerifier: String(rows[index][3] || "").toLowerCase(),
        position: String(rows[index][4] || ""),
        requestedRole: String(rows[index][5] || ""),
        role: String(rows[index][6] || ""),
        status: String(rows[index][7] || "").toUpperCase(),
        createdAt: rows[index][8],
        updatedAt: rows[index][9],
        approvedBy: String(rows[index][10] || ""),
      };
    }
  }
  return null;
}

function countActiveDevelopers_(sheet) {
  return dataRows_(sheet, ACCOUNT_HEADERS).filter(function (row) {
    return (
      String(row[6] || "") === "Developer" &&
      String(row[7] || "").toUpperCase() === "ACTIVE"
    );
  }).length;
}

function writeAudit_(spreadsheet, actor, action, txId, detail) {
  spreadsheet.getSheetByName(SHEET_AUDIT).appendRow([
    nowText_(),
    actor.username,
    actor.role,
    action,
    txId || "",
    cleanText_(detail, 500, false),
  ]);
}

function bumpRevision_() {
  const properties = PropertiesService.getScriptProperties();
  const current = Number(properties.getProperty("DATA_REVISION") || "0");
  const next = Number.isFinite(current) ? current + 1 : Date.now();
  properties.setProperty("DATA_REVISION", String(next));
  return String(next);
}

function withScriptLock_(callback) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    return callback();
  } finally {
    lock.releaseLock();
  }
}

function createServerBackup_() {
  const spreadsheet = getSpreadsheet_();
  const source = DriveApp.getFileById(spreadsheet.getId());
  const folderId = getProperty_("DRIVE_FOLDER_ID", "");
  const folder = folderId ? DriveApp.getFolderById(folderId) : DriveApp.getRootFolder();
  const name =
    "WMS_BACKUP_" +
    Utilities.formatDate(new Date(), "Asia/Jakarta", "yyyyMMdd_HHmmss");
  const copy = source.makeCopy(name, folder);
  const time = nowText_();
  const properties = PropertiesService.getScriptProperties();
  properties.setProperties({
    LAST_BACKUP_TIME: time,
    LAST_BACKUP_URL: copy.getUrl(),
    LAST_BACKUP_NAME: name,
  });
  return {
    backup_time: time,
    backup_url: copy.getUrl(),
    backup_name: name,
  };
}

function backupTriggerInstalled_() {
  return ScriptApp.getProjectTriggers().some(function (trigger) {
    return trigger.getHandlerFunction() === "scheduledDailyBackup";
  });
}

function saveEvidence_(payload) {
  const encoded = String(payload.image_base64 || "");
  if (!encoded) {
    return "";
  }
  const bytes = Utilities.base64Decode(encoded);
  if (bytes.length > 6 * 1024 * 1024) {
    throw new Error("Ukuran bukti melebihi 6 MB.");
  }
  const folderId = getProperty_("DRIVE_FOLDER_ID", "");
  const folder = folderId ? DriveApp.getFolderById(folderId) : DriveApp.getRootFolder();
  const fileName = cleanText_(payload.image_name || "bukti.jpg", 120, true).replace(
    /[^A-Za-z0-9._-]/g,
    "_"
  );
  const blob = Utilities.newBlob(bytes, "image/jpeg", fileName);
  return folder.createFile(blob).getUrl();
}

function stockAlert_(name, quantity, minimum) {
  if (quantity <= 0) {
    return "🚨 STOK HABIS\n📦 " + name + "\nSisa: 0 pcs";
  }
  if (quantity <= minimum) {
    return (
      "⚠️ STOK KRITIS\n📦 " +
      name +
      "\nSisa: " +
      quantity +
      " pcs\nMinimum: " +
      minimum +
      " pcs"
    );
  }
  return "";
}

function normalizeUsername_(value) {
  const username = String(value || "").trim().toLowerCase();
  if (!/^[a-z0-9._-]{4,32}$/.test(username)) {
    throw new Error("Username tidak valid.");
  }
  return username;
}

function normalizeRole_(value) {
  const text = String(value || "").trim().toLowerCase();
  const roles = {
    staff: "Staff",
    admin: "Admin",
    boss: "Boss",
    bos: "Boss",
    developer: "Developer",
  };
  const role = roles[text];
  if (!role) {
    throw new Error("Role tidak valid.");
  }
  return role;
}

function normalizeItemStatus_(value) {
  const text = String(value || "Aktif").trim().toLowerCase();
  if (text === "aktif") {
    return "Aktif";
  }
  if (text === "nonaktif" || text === "non-aktif" || text === "inactive") {
    return "Nonaktif";
  }
  throw new Error("Status barang tidak valid.");
}

function cleanText_(value, maxLength, required) {
  const text = String(value === undefined || value === null ? "" : value)
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "")
    .trim();
  if (required && !text) {
    throw new Error("Input wajib diisi.");
  }
  if (text.length > maxLength) {
    throw new Error("Input melebihi batas " + maxLength + " karakter.");
  }
  return text || "-";
}

function intValue_(value, label) {
  const text = String(value).trim();
  if (!/^-?\d+(?:\.0+)?$/.test(text)) {
    throw new Error(label + " bukan angka bulat yang valid.");
  }
  return Number(text);
}

function nonNegativeInt_(value, label) {
  const result = intValue_(value, label);
  if (result < 0) {
    throw new Error(label + " tidak boleh negatif.");
  }
  return result;
}

function positiveInt_(value, label) {
  const result = intValue_(value, label);
  if (result < 1) {
    throw new Error(label + " minimal 1.");
  }
  return result;
}

function sameText_(left, right) {
  return String(left || "").trim().toLowerCase() ===
    String(right || "").trim().toLowerCase();
}

function nowText_() {
  return Utilities.formatDate(
    new Date(),
    "Asia/Jakarta",
    "dd-MM-yyyy HH:mm:ss"
  );
}

function getProperty_(name, fallback) {
  const value = PropertiesService.getScriptProperties().getProperty(name);
  return value === null || value === undefined ? fallback : value;
}

function getRequiredProperty_(name) {
  const value = getProperty_(name, "");
  if (!value) {
    throw new Error("Script Property " + name + " belum diisi.");
  }
  return value;
}

function safeError_(error) {
  let text = String(error && error.message ? error.message : error || "Operasi gagal.");
  [
    getProperty_("API_SHARED_KEY", ""),
    getProperty_("AUTH_SIGNING_KEY", ""),
    getProperty_("ACCOUNT_TELEGRAM_BOT_TOKEN", ""),
  ].forEach(function (secret) {
    if (secret) {
      text = text.split(secret).join("***REDACTED***");
    }
  });
  return text.slice(0, 500);
}

function jsonResponse_(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(
    ContentService.MimeType.JSON
  );
}

function setupTelegramApprovalWebhook() {
  const token = getRequiredProperty_("ACCOUNT_TELEGRAM_BOT_TOKEN");
  let secret = getProperty_("TELEGRAM_WEBHOOK_SECRET", "");
  if (!secret) {
    secret = Utilities.getUuid().replace(/-/g, "") +
      Utilities.getUuid().replace(/-/g, "");
    PropertiesService.getScriptProperties().setProperty(
      "TELEGRAM_WEBHOOK_SECRET",
      secret
    );
  }
  const serviceUrl = ScriptApp.getService().getUrl();
  if (!serviceUrl) {
    throw new Error("Deploy Web App terlebih dahulu.");
  }
  const webhookUrl =
    serviceUrl + "?telegram_secret=" + encodeURIComponent(secret);
  const response = UrlFetchApp.fetch(
    "https://api.telegram.org/bot" + token + "/setWebhook",
    {
      method: "post",
      contentType: "application/json",
      payload: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["callback_query"],
        drop_pending_updates: true,
      }),
      muteHttpExceptions: true,
    }
  );
  const result = JSON.parse(response.getContentText());
  if (!result.ok) {
    throw new Error("Telegram menolak webhook: " + String(result.description || ""));
  }
  return result;
}

function handleTelegramWebhook_(e) {
  try {
    const expectedSecret = getRequiredProperty_("TELEGRAM_WEBHOOK_SECRET");
    if (
      !constantTimeEqual_(
        String(e.parameter.telegram_secret || ""),
        expectedSecret
      )
    ) {
      throw new Error("Webhook secret tidak valid.");
    }
    const update = parseJsonBody_(e);
    const callback = update.callback_query;
    if (!callback || !callback.data) {
      return jsonResponse_({ ok: true, ignored: true });
    }

    const approverId = getProperty_("TELEGRAM_APPROVER_USER_ID", "");
    if (
      approverId &&
      String(callback.from && callback.from.id) !== String(approverId)
    ) {
      answerTelegramCallback_(
        callback.id,
        "Anda tidak memiliki izin menyetujui akun."
      );
      return jsonResponse_({ ok: true, ignored: true });
    }

    const parts = String(callback.data).split("|");
    if (parts.length !== 3 || parts[0] !== "acc") {
      throw new Error("Callback Telegram tidak valid.");
    }
    const requestId = parts[1];
    const decision = parts[2];
    if (
      decision !== "REJECT" &&
      ["Staff", "Admin"].indexOf(decision) < 0
    ) {
      throw new Error(
        "Role Boss dan Developer hanya dapat diberikan dari halaman Kelola Akun."
      );
    }

    const result = withScriptLock_(function () {
      const spreadsheet = getSpreadsheet_();
      ensureSchema_(spreadsheet);
      const sheet = spreadsheet.getSheetByName(SHEET_ACCOUNTS);
      const account = findAccount_(sheet, requestId);
      if (!account) {
        throw new Error("Permintaan akun tidak ditemukan.");
      }
      if (account.status !== "PENDING") {
        throw new Error("Permintaan akun sudah diproses.");
      }
      const actor = { username: "Telegram Approver", role: "Developer" };
      if (decision === "REJECT") {
        sheet.getRange(account.row, 7, 1, 5).setValues([
          ["", "REJECTED", account.createdAt, nowText_(), actor.username],
        ]);
        writeAudit_(
          spreadsheet,
          actor,
          "ACCOUNT_REJECT",
          account.requestId,
          account.username
        );
        bumpRevision_();
        return "Permintaan @" + account.username + " ditolak.";
      }
      sheet.getRange(account.row, 7, 1, 5).setValues([
        [decision, "ACTIVE", account.createdAt, nowText_(), actor.username],
      ]);
      writeAudit_(
        spreadsheet,
        actor,
        "ACCOUNT_APPROVE",
        account.requestId,
        account.username + " sebagai " + decision
      );
      bumpRevision_();
      return "Akun @" + account.username + " aktif sebagai " + decision + ".";
    });

    answerTelegramCallback_(callback.id, result);
    return jsonResponse_({ ok: true });
  } catch (error) {
    console.error("[Telegram webhook] " + safeError_(error));
    return jsonResponse_({ ok: false, message: safeError_(error) });
  }
}

function answerTelegramCallback_(callbackId, message) {
  const token = getRequiredProperty_("ACCOUNT_TELEGRAM_BOT_TOKEN");
  UrlFetchApp.fetch(
    "https://api.telegram.org/bot" + token + "/answerCallbackQuery",
    {
      method: "post",
      contentType: "application/json",
      payload: JSON.stringify({
        callback_query_id: callbackId,
        text: String(message).slice(0, 180),
        show_alert: true,
      }),
      muteHttpExceptions: true,
    }
  );
}
