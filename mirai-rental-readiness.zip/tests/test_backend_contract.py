import subprocess
from pathlib import Path


def test_apps_script_mutation_contracts():
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        ["node", str(root / "tests" / "backend_contract.js")],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "backend contract regressions passed" in result.stdout
