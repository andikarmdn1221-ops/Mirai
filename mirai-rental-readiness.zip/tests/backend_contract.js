/* Regression harness for the Apps Script backend; no network or Google APIs. */
const assert = require("assert");
const fs = require("fs");
const vm = require("vm");

const source = fs.readFileSync("Code_Accounts.gs", "utf8");
const STOCK_HEADERS = ["Nama Barang", "Jumlah Stok", "Status", "Batas Minimum", "ID Barang"];
const HISTORY_HEADERS = [
  "ID Transaksi", "Waktu", "Tanggal", "Tipe", "Barang", "Jumlah",
  "Pembeli / Keterangan", "Bukti URL", "Status", "Referensi", "ID Barang",
];
const AUDIT_HEADERS = ["Waktu", "User", "Role", "Aksi", "ID Transaksi", "Detail"];

class Sheet {
  constructor(rows) {
    this.rows = rows.map((row) => row.slice());
    this.failAppend = false;
  }
  getLastRow() { return this.rows.length; }
  getLastColumn() { return Math.max(0, ...this.rows.map((row) => row.length)); }
  getFrozenRows() { return 1; }
  setFrozenRows() {}
  getRange(row, col, rowCount = 1, colCount = 1) {
    return {
      getValues: () => Array.from({ length: rowCount }, (_, i) =>
        Array.from({ length: colCount }, (_, j) => this.rows[row - 1 + i]?.[col - 1 + j] ?? "")),
      setValue: (value) => { this.rows[row - 1][col - 1] = value; },
      setValues: (values) => {
        for (let i = 0; i < rowCount; i += 1) {
          while (!this.rows[row - 1 + i]) this.rows[row - 1 + i] = [];
          for (let j = 0; j < colCount; j += 1) this.rows[row - 1 + i][col - 1 + j] = values[i][j];
        }
      },
    };
  }
  appendRow(row) {
    if (this.failAppend) throw new Error("SIMULATED_APPEND_FAILURE");
    this.rows.push(row.slice());
  }
  deleteRow(row) { this.rows.splice(row - 1, 1); }
  insertRowBefore(row) { this.rows.splice(row - 1, 0, []); }
  clearContents() { this.rows = []; }
}

function setup(historyRows = []) {
  const sheets = {
    stok: new Sheet([STOCK_HEADERS, ["Primer", 10, "Aktif", 5, "ITM-PRIMER"]]),
    riwayat: new Sheet([HISTORY_HEADERS, ...historyRows]),
    audit: new Sheet([AUDIT_HEADERS]),
    accounts: new Sheet([["header"]]),
  };
  const context = vm.createContext({
    console,
    SpreadsheetApp: { flush() {} },
    Utilities: { getUuid: () => "00000000-0000-4000-8000-000000000000" },
  });
  vm.runInContext(source, context);
  context.getSpreadsheet_ = () => ({ getSheetByName: (name) => sheets[name] });
  context.ensureSchema_ = () => {};
  context.resolveActor_ = () => ({ username: "review", role: "Developer" });
  context.nowText_ = () => "16-09-2026 12:00:00";
  context.bumpRevision_ = () => "1";
  return { context, sheets };
}

function transactionPayload(overrides = {}) {
  return {
    tipe: "KELUAR",
    barang: "Primer",
    jumlah: 2,
    keterangan: "Project",
    tx_id: "TX-REGRESSION",
    waktu: "16-09-2026 12:00:00",
    tanggal: "16-09-2026",
    expected_stock_before: 10,
    ...overrides,
  };
}

{
  const { context, sheets } = setup();
  sheets.riwayat.failAppend = true;
  assert.throws(() => context.handleTransaction_(transactionPayload()), /SIMULATED_APPEND_FAILURE/);
  assert.strictEqual(sheets.stok.rows[1][1], 10, "stock must roll back when history append fails");
  assert.strictEqual(sheets.riwayat.rows.length, 1, "failed transaction must not leave history");
  assert.strictEqual(sheets.audit.rows.length, 1, "failed transaction must not leave audit");
}

{
  const { context, sheets } = setup();
  sheets.audit.failAppend = true;
  assert.throws(() => context.handleTransaction_(transactionPayload()), /SIMULATED_APPEND_FAILURE/);
  assert.strictEqual(sheets.stok.rows[1][1], 10, "stock must roll back when audit append fails");
  assert.strictEqual(sheets.riwayat.rows.length, 1, "audit failure must roll back history");
  assert.strictEqual(sheets.audit.rows.length, 1, "audit failure must not leave an audit row");
}

{
  const { context, sheets } = setup();
  context.handleTransaction_(transactionPayload());
  context.handleTransaction_(transactionPayload());
  assert.strictEqual(sheets.stok.rows[1][1], 8, "same transaction ID must be idempotent");
  assert.strictEqual(sheets.riwayat.rows.length, 2, "same transaction ID must not append twice");
}

{
  const { context, sheets } = setup();
  const payload = {
    barang: "Primer",
    stok_baru: 8,
    expected_stock_before: 10,
    alasan: "Stock opname",
    tx_id: "ADJ-REGRESSION",
    waktu: "16-09-2026 12:00:00",
    tanggal: "16-09-2026",
  };
  context.handleStockAdjust_(payload);
  context.handleStockAdjust_(payload);
  assert.strictEqual(sheets.stok.rows[1][1], 8, "same adjustment ID must be idempotent");
  assert.strictEqual(sheets.riwayat.rows.length, 2, "same adjustment ID must not append twice");
}

{
  const { context, sheets } = setup();
  const payload = transactionPayload({
    barang: "Nama Primer Lama",
    item_id: "ITM-PRIMER",
    tx_id: "TX-ID-REGRESSION",
  });
  context.handleTransaction_(payload);
  assert.strictEqual(sheets.stok.rows[1][1], 8, "stable item ID must resolve a renamed display name");
  assert.strictEqual(sheets.riwayat.rows[1][4], "Primer", "history stores the current display name");
}

{
  const history = [["TX-OLD", "16-09-2026 11:00:00", "16-09-2026", "MASUK", "Primer", 2, "Supplier", "", "AKTIF", "", "ITM-PRIMER"]];
  const { context, sheets } = setup(history);
  sheets.stok.rows[1][1] = 12;
  context.handleMasterUpdate_({ old_nama: "Primer", new_nama: "Primer Baru", status: "Aktif", min_stok: 5 });
  assert.strictEqual(sheets.riwayat.rows[1][4], "Primer Baru", "rename must update historical display name");
  assert.throws(() => context.handleMasterDelete_({ nama: "Primer Baru" }), /memiliki riwayat/);
  context.handleTransactionVoid_({ tx_id: "TX-OLD" });
  context.handleTransactionVoid_({ tx_id: "TX-OLD" });
  assert.strictEqual(sheets.stok.rows[1][1], 10, "void must resolve renamed item by stable ID");
}

console.log("backend contract regressions passed");
